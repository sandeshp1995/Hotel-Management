package com.app.dao;

import javax.sql.DataSource; 

public interface UserDAO {

	public void setDataSource(DataSource ds);
	
	public boolean getUserName(String username, String password);
}
