/*package com.app.dao;

import com.app.management.UserData;

public interface UserDAO {
	
	public UserData getUser(String userName);
}
*/
package com.app.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.app.management.UserData;

@Repository
public class UserDAO{
	@Autowired
	private static JdbcTemplate jdbcTemplate;
	
	public static void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		UserDAO.jdbcTemplate = jdbcTemplate;
	}



	public static List<UserData> getUsers(){
		return jdbcTemplate.query("select * from login", new RowMapper<UserData> () {
			
			public UserData mapRow(ResultSet rs, int rowNum) throws SQLException {
			      UserData userData = new UserData();
			      userData.setUserName(rs.getString("userName"));
			      userData.setPassword(rs.getString("password"));
			      System.out.println("I m in UserMapper");
			      return userData;
			   }
		});
	}
	
	public static Boolean insertUser(UserData userData) {
		int ins = jdbcTemplate.update("insert into login(username,password) values(?,?)", new Object[] {userData.getUserName(), userData.getPassword()});
		if(ins > 0) {
			return true;
		}
		else {
			return false;
		}
	}
}
