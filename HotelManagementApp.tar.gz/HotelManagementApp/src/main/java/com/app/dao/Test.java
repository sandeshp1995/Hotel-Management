package com.app.dao;

import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;
import com.app.management.UserData;

public class Test implements UserDAO {
	private JdbcTemplate jdbcTemplateObject;

	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	}

	public boolean getUserName(String userName, String password) {
		String SQL = "Select * from login where username=?";
		UserData user = jdbcTemplateObject.queryForObject(SQL, new Object[] { userName }, new UserMapper());
		if (password.equals(user.getPassword())) {
			return true;
		} else {
			return false; 
		}
	}
}
