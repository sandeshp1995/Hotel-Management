/*package com.app.dao;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.app.management.UserData;

public class Test implements UserDAO {
	   private DataSource dataSource;
	   private JdbcTemplate jdbcTemplateObject;
	   
	   public void setDataSource(DataSource dataSource) {
	      this.dataSource = dataSource;
	      this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	   }
	public UserData getUser(String userName) {
		String SQL = "Select * from login where username=?";
		System.out.println(SQL);
		UserData user = (UserData) jdbcTemplateObject.queryForObject(SQL, new Object[] { userName }, new UserMapper());
		return user;
		
				if (password.equals(user.getPassword())) {
			System.out.println("return true");
			return true;
		} else {
			System.out.println("return false");
			return false; 
		}
	}
}
*/