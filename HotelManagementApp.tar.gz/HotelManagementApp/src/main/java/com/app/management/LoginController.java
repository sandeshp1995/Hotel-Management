package com.app.management;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.app.dao.UserDAO;
@Controller
public class LoginController {
	@RequestMapping("/")
	public ModelAndView login() {
		return new ModelAndView("login","obj", new UserData());
	}
	
/*	@RequestMapping(value="/submit", method=RequestMethod.POST)
	public ModelAndView showLogin(@ModelAttribute("data") UserData data) {

		System.out.println("name :: "+data.getUserName()+"  Pass :: "+data.getPassword() );
		String name= data.getUserName();
		UserData user = Test.getUser(name);
		String msg= "hello";
		if(data.getPassword().equals(user.getPassword())) {
			return new ModelAndView("welcomepage","message", msg );
		} else {
			return new ModelAndView("errorpage", "message", "Sorry, username or password error");
		}	
	}
*/	
	@RequestMapping("/register")
	public ModelAndView register() {
		return new ModelAndView("register","obj", new UserData());
	}
	@RequestMapping(value= "/userslist", method=RequestMethod.POST)
	public ResponseEntity<Map<String, Object>> getUsers() {
		Map<String, Object> map=new HashMap<String, Object>();
		map.put("user", UserDAO.getUsers());
		return new ResponseEntity<Map<String,Object>>(map, HttpStatus.OK);
	}
	@RequestMapping(value= "/userInsert", method=RequestMethod.POST)
	public String insertUser(@ModelAttribute("userData") UserData userData) {
		userData.setUserName(userData.getUserName());
		userData.setPassword(userData.getPassword());
		UserDAO.insertUser(userData);
		return "welcomepage";
	}
	 
	
}
