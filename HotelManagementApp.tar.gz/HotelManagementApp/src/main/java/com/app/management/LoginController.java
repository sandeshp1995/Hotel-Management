package com.app.management;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.app.dao.Test;
@Controller
public class LoginController {
	@RequestMapping("/")
	public ModelAndView login() {
		return new ModelAndView("login","obj", new UserData());
	}
	
	@RequestMapping(value="/submit", method=RequestMethod.POST)
	public ModelAndView showLogin(@ModelAttribute("data") UserData data) {

		System.out.println("name :: "+data.getUserName()+"  Pass :: "+data.getPassword() );
		Test.getUserName(data.getUserName(), data.getPassword());
		return new ModelAndView("welcomepage","test","success" );
/*		if (data.getPassword().equals("admin")) {
			String message = "HELLO " + data.getUserName();
			return new ModelAndView("welcomepage", "message", message);
		} else {
			return new ModelAndView("errorpage", "message", "Sorry, username or password error");
		}
*/	
	}

}
